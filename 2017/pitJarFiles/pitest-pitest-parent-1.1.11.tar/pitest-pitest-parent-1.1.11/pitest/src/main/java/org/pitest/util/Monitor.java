package org.pitest.util;

public interface Monitor {

  void requestStop();

  void requestStart();

}
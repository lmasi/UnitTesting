mvn -Darguments="-Dcheckstyle.skip=true" release:perform

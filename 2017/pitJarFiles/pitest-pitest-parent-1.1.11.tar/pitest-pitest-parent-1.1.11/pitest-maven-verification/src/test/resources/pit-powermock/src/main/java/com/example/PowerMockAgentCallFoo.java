package com.example;

public class PowerMockAgentCallFoo {

  public void call() {
    PowerMockAgentFoo.foo();
  }
}
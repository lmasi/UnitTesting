package sample;

import com.google.gwt.user.client.rpc.RemoteService;

public interface MyService extends RemoteService {
  String getData();
}

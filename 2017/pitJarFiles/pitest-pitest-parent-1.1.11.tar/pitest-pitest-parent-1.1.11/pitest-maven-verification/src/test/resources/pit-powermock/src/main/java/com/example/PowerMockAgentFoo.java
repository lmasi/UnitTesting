package com.example;

public class PowerMockAgentFoo {
  public static void foo() {
    System.out.println("static method called");
  }
}

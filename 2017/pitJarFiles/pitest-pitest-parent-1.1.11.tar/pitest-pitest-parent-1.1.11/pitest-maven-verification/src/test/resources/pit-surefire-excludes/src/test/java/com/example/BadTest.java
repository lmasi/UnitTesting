package com.example;

import java.util.Arrays;
import java.util.Collection;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

public class BadTest {
  
  @Test
  public void aTest() {
    assertEquals(1, 2);
  }

}

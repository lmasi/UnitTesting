package com.example;

public class PowerMockCallFoo {

  public void call() {
    PowerMockFoo.foo();
  }
}

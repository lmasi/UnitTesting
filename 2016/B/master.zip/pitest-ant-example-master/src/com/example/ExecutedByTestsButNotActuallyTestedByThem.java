package com.example;

public class ExecutedByTestsButNotActuallyTestedByThem {

  public int returnOne() {
    return 1;
  }
  
}

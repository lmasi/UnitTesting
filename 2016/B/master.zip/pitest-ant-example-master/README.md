# pitest ant example

Simple example of using http://pitest.org with ant.

To mutation test just run

ant pit

A report will be generated in the pitReports directory
